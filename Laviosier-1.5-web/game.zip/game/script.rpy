﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

init python:
    valid_phrases = [
    'On May 8 1794 Lavoisier will be beheaded in front of the country he loves',
    'On May 8 1794 in front of the country he loves Lavoisier will be beheaded',
    'On May 8th, 1794, in front of the country he loves, Lavoisier will be beheaded',
    
]
    name_list = ['sixseven', 'tungtungtungsahur', 'sigma'] 
    renpy.music.register_channel('voicefx', mixer='sfx', loop=False)

    renpy.add_layer('young_layer', above='master')
    renpy.add_layer('father_layer', above='master')
    renpy.add_layer('background', below='master')
    
    message = False

    def speak(event, interact=True, **kwargs):
        if not interact:
            return
        if event == 'show':
            renpy.music.play('speaking.mp3', channel='voicefx')
        elif event == 'slow_done' or event == 'end':
            renpy.music.stop(channel='voicefx')

    def narrator_callback(event, interact=True, **kwargs):
        if not interact:
            return
        if event == 'show':
            renpy.music.play('keyboard.mp3', channel='voicefx')
        elif event == 'slow_done' or event == 'end':
            renpy.music.stop(channel='voicefx')
    def femalespeak(event, interact=True, **kwargs):
        if not interact:
            return
        if event == 'show':
            renpy.music.play('femalespeak.mp3', channel='voicefx')
        elif event == 'slow_done' or event == 'end':
            renpy.music.stop(channel='voicefx')
    def clamp_short(value, min_val, max_val):
        return max(min_val, min(value, max_val))
    def get_ph_value(love):

        love = clamp_short(love, -7, 7)
        ph = love
        return ph
 
init:
    default question_asked1 = False
    default question_asked2 = False
    default books_read = 0
    default choice_a = False
    default choice_b = False
    default choice_c = False
    default furnace_on = 0
    default tube_on = 0
    default candlejar_on = 0
    default bowl_on = 0
    default table_on = 0
    default love = 0
    transform lcharacter:
        zoom 0.6 
        xalign 1.0
        yalign 1.0
    transform thinking_char:
        zoom 0.6
        xalign 0.34
        yalign 1.0
    transform lcharacter_left:
        zoom 0.6
        xalign 0.0
        yalign 1.0
    transform lchar_flip:
        zoom 0.6
        xzoom -1
        xalign 1.0
        yalign 1.0
    transform lcharleft_flip:
        zoom 0.6
        xzoom -1
        xalign 0.0
        yalign 1.0
    transform bg_zoom:
        zoom 2.0
        xalign 0.5
        yalign 0.5
    transform bgzoom:
        xalign 0.5
        yalign 0.5
        zoom 10.0
    transform bg_home:
        zoom 1.25
        xalign 0.5
        yalign 0.5
    transform guillaume_lecture:
        zoom 0.45
        xzoom -1
        xalign 0.0
        yalign 1.0
    image lavoisier neutral = 'lavoisier neutral.png'
    image lavoisier happy = 'lavoisier happy.png'
    image lavoisier angry = 'lavoisier angry.png'
    image lavoisier shocked = 'lavoisier shocked.png'
    image lavoisier sad = 'lavoisier sad.png'
    image lavoisier young = 'lavoisier young.png'
    image lavoisier = 'lavoisier happy.png'
    image  home = 'lavoisier home.png'
    image animated_bookshelf:
        'bookshelf one.png'
        pause 0.15
        'bookshelf two.png'
        pause 0.15
        'bookshelf three.png'
        pause 0.15
        'bookshelf four.png'
        pause 0.15
        repeat
    image lavoisier thinking:
        'lavoisier thinking1.png'
        pause 0.5
        'lavoisier thinking2.png'
        pause 0.5
        'lavoisier thinking3.png'
        pause 0.5
        'lavoisier thinking4.png'
        pause 0.5
        repeat



    
    define l = Character('Lavoisier', callback=speak, color='#ffe100ff', image ="lavoisier")
    define y = Character('You', callback=speak, color='#0090deff')
    define yl = Character('Young Lavoisier', callback = speak, color= '#c30f0fff')
    define n = Character(None, callback = narrator_callback, color= '#ffffffff')
    define m = Character('Marie(Wife)', callback = femalespeak, color= '#ffa0a0ff')
    define f = Character('Father', callback = femalespeak, color= '#159f00ff')
    define g = Character('Guillaume Franåois Rouelle', callback = femalespeak, color= '#7000ccff')
    define huh = Character('???', callback = femalespeak, color= '#545454ff')






screen workstation():

    add 'table off.png'

    # Furnace
    $ furnace_image = 'furnace on.png' if furnace_on else 'furnace off.png'
    $ furnace_hover = 'furnace hover.png'
    imagebutton:
        idle furnace_image
        hover furnace_hover
        action If(furnace_on == 0, Jump('furnace'))
        xpos 0
        ypos 0
        focus_mask True

    # Tube
    $ tube_image = 'tube on.png' if tube_on else 'tube off.png'
    $ tube_hover = 'tube hover.png'
    imagebutton:
        idle tube_image
        hover tube_hover
        action If(tube_on == 0, Jump('tube'))
        xpos 0
        ypos 0
        focus_mask True

    # Bowl
    $ bowl_image = 'bowl on.png' if bowl_on else 'bowl off.png'
    $ bowl_hover = 'bowl hover.png'
    imagebutton:
        idle bowl_image
        hover bowl_hover
        action If(bowl_on == 0, Jump('bowl'))
        xpos 0
        ypos 0
        focus_mask True

    # Candle/Jar
    $ candle_image = 'candlejar on.png' if candlejar_on else 'candlejar off.png'
    $ candle_hover = 'candlejar hover.png'
    imagebutton:
        idle candle_image
        hover candle_hover
        action If(candlejar_on == 0, Jump('candlejar'))
        xpos 0
        ypos 0
        focus_mask True
label splashscreen:
    $ start = "Normal"
    menu:
        n "Do you want to play the normal game or the shortened version?"
        "Normal":
            $ start = "Normal"
        "Shortened":
            $ start = "Shortened"
    return
    # The game starts here.

label start:

    play music 'backgroundmusic.mp3' loop
    $ renpy.music.set_volume(0.3)
    scene chem room at bg_zoom
    show lavoisier neutral at lcharacter

    n 'Meet Antoine Lavoisier, who is often called the father of modern chemistry.'
    show lavoisier happy at lcharacter
    l '"Yes… that is I, Antoine Lavoisier."' with vpunch
    scene college at bg_zoom
    with fade
    show lavoisier sad at lchar_flip
    n 'He was seventeen when he left Mazarin College in Paris, in 1761.'
    l sad 'I studied law to please my family, but I found it dull… my heart was drawn to science.'
    hide lavoisier sad
    jump player_plays

label player_plays:
    scene black
    centered "Disclaimer: \n This game is a work of historical fiction. \n Some events and characters have been altered for narrative purposes."
    centered "You are playing as Lavoisier's assistant in 1775 Paris. \n Your choices will affect your relationship with Lavoisier and ending."
    centered "Hôtel de la Ferme Générale \n Paris, France \n 1775"
    y "{i}Finally, I AM HERE!{/i}"
    y "{i}My new work as the genius's assistant!{/i}"
    y "{i}I better go in!{/i}"
    scene animated_bookshelf at bgzoom
    with fade
    show lavoisier happy at lcharacter
    with moveinright
    y "{i}Okay… breathe. Don’t embarrass yourself in front of a legend.{/i}"
    y "{i}He’s smiling, but that could be dangerous…{/i}"

    l 'Hello, you must be the assistant, right?'
    menu:
        'Yes, I am.':
            y 'Yes, I am.'
            l neutral 'Oh, nice, but I forget, what is your name?'
        'No, I do not know what you are talking about.':
            y 'No. I dont know what youre talking about.'
            l thinking 'Huh, no, you look exactly the same as the photo you sent.'
            l 'But, what is your name?'
    $ name = renpy.input('Whats your name?')
    if name in name_list:
        l angry '{i}What is that name! How unrefined.{/i}'
    else:
        l '[name] is a pleasant name.'
    l "Anyways, nice to meet you."

    menu:
        'Same.':
            $ love += 1
            y 'Same.'
            l 'Nice.'  
        'Not really.':
            $ love -= 1
            y 'Not at all. I hate YOU, and YOU specifically!'
            hide lavoisier
            show lavoisier sad at lcharacter
            l 'Oh...'
            hide lavoisier
            show lavoisier angry at lcharacter
            l 'WHAT HAVE I DONE?!'
            
        'I hate you':
            $ love -= 1
            hide lavoisier happy
            show lavoisier shocked at lcharacter
            y 'I hate YOU, and YOU specifically!'
            l 'WHAT HAVE I DONE?!'
    l neutral "Anyways..."
    l 'Are you a girl, a boy, or something else?'
    menu:
        'Girl':
            $ gender = 'She'
        'Boy':
            $ gender = 'He'
        'Other':
            $ gender = 'They'

    hide lavoisier
    show lavoisier happy at lcharacter
    y "{i}So this is Antoine Lavoisier… he doesn’t look like someone you argue with.{/i}"
    if start == "Normal":
        l 'Anyways, I believe we should know more about each other!'
        l 'So [name], do you want to learn about how I became a chemist?'

        n 'Learn about Lavoisier?'

        menu:
            'I am quite fine':
                l 'Well, I control your paycheck, so you have to listen to me!'
                y "{i}Okay… note to self: do not test this man’s patience.{/i}"

                $ love -= 1

                
            'Sure':
                l 'Alright, nice.'
                $ love += 1

                

        jump lavoisier_child

        
    else:
        l "As a child, I was smart and rich."
        l "My father forced me to study law, but I followed my heart and pursued science."
        l "I learned about the four elements and phlogiston from my chemistry teacher, Guillaume Franåois Rouelle."
        l "Phlogiston theory stated that combustible materials contained a substance called phlogiston that was released during burning, losing mass."
        l "And the four elements were earth, air, fire, and water, believed to be the fundamental building blocks of nature by Aristotle."
        jump lavoisier_back_in_study
label lavoisier_child:
    scene black
    with fade
    show lavoisier young at lcharacter onlayer young_layer

    l "When I was a wee lad, I was two things, smart and rich."
    l "My mother, Émilie Punctis, died when I was 5 years old, which is how I was able to inherit enough wealth to fund my research and live a lavish life."

    scene child home
    with fade
    show lavoisier father at lcharleft_flip onlayer father_layer

    f "Son, you will follow my footsteps and study law!"

    menu:
        yl "Should I study law?"
        "Yes":
            yl "Yes, Father."
            f "Good. I expect nothing less."
        "No":
            yl "No, Father. I do not see the appeal in law."
            f "Well son, that is NOT acceptable."
            f "YOU WILL STUDY LAW!"

    y "{i}Smart, rich, and still pushed into a life he didn’t want…{/i}"

    scene college at bg_zoom
    with fade
    hide lavoisier onlayer young_layer
    hide lavoisier onlayer father_layer
    show lavoisier happy at lcharacter

    l neutral "I persisted and studied law throughout my time at Mazarin College and graduated at 17."
    l "During my time there, I listened to the lectures of a man named Guillaume Franåois Rouelle, which is when I learned phlogiston."

    scene college lecture at bg_zoom
    with fade
    hide lavoisier
    show guillaume lecture at guillaume_lecture
    show lavoisier young at lcharacter

    huh "And that is our understanding of chemistry."
    yl "Wow, I never knew chemistry could be so cool!"

    $ question_asked = False

    while True:

        if question_asked1 and question_asked2:
            l "All right, I understand it now."
            jump lavoisier_back_in_study

        elif question_asked1 or question_asked2:
            yl "I still have that other question, so I'll ask him."
            menu:
                yl "What should I ask?"
                "Phlogiston" if not question_asked1:
                    yl "Sir, what is phlogiston?"
                    g "Lavoisier, tsk tsk tsk."
                    yl "Sorry sir..."
                    g "Phlogiston theory was developed by Georg Ernst Stahl around 1697."
                    g "He says that all combustible materials had a fiery substance called phlogiston in them that was released when the material was burned."
                    yl "Okay, that checks with my notes."
                    g "The less substance left over signaled that it had a lot of phlogiston content that was lost to the air and, once the phlogiston was released, the substance stopped burning."
                    yl "Alright, that makes sense."
                    $ question_asked1 = True

                "4 Elements" if not question_asked2:
                    yl "Sir, what are the four elements?"
                    g "Honestly, I'm disappointed in you, Lavoisier."
                    yl "Sorry sir..."
                    g "The four elements are earth, air, fire, and water."
                    g "These were proposed by Aristotle and were believed to be the fundamental building blocks of nature."
                    yl "Okay, that also makes sense."
                    $ question_asked2 = True

        elif not question_asked:
            yl "I am a bit confused on two things..."
            yl "I should ask Sir Guillaume a question."
            menu:
                yl "What should I ask?"
                "Phlogiston" if not question_asked1:
                    yl "Sir, what is phlogiston?"
                    g "Lavoisier, tsk tsk tsk."
                    yl "Sorry sir..."
                    g "Phlogiston theory was developed by Georg Ernst Stahl around 1697."
                    g "He says that all combustible materials had a fiery substance called phlogiston in them that was released when the material was burned."
                    yl "Okay, that checks with my notes."
                    g "The less substance left over signaled that it had a lot of phlogiston content that was lost to the air and, once the phlogiston was released, the substance stopped burning."
                    yl "Alright, that makes sense."
                    $ question_asked1 = True

                "4 Elements" if not question_asked2:
                    yl "Sir, what are the four elements?"
                    g "Honestly, I'm disappointed in you, Lavoisier."
                    yl "Sorry sir..."
                    g "The four elements are earth, air, fire, and water."
                    g "These were proposed by Aristotle and were believed to be the fundamental building blocks of nature."
                    yl "Okay, that also makes sense."
                    $ question_asked2 = True

    scene black with fade
    scene animated_bookshelf at bgzoom
    with fade
    show lavoisier happy at lcharacter
    with moveinright

    y "{i}Wait… I think I’m starting to get this… maybe I actually understand chemistry?!{/i}"
    y "{i}He makes complicated stuff sound simple. How does he do that?{/i}"
    y "{i}Wow, he’s intense… in a focused, scary genius kind of way.{/i}"

    jump lavoisier_back_in_study

label lavoisier_back_in_study:
    scene black
    scene home at bg_home
    with fade
    show lavoisier happy at lcharacter

    l 'Things in alchemy really started changing when I left law to pursue science in 1772.'
    y "{i}He talks like he already knows the answer to everything.{/i}"

    l 'And that, [name], is when chemistry really got started…'

    menu:
        l 'Would you like to hear more about my discovery of oxygen?'
        'Yes, tell me!':
            $ love += 1

            show lavoisier happy at lcharacter
            l 'I see you are practically *floating* at the thought!'
            
        'No thanks.':
            $ love -= 1

            show lavoisier sad at lcharacter
            l 'Well, now I know who that one kid is at the back of the classroom…'
            

    show lavoisier thinking at thinking_char
    l 'Ah, my glory days… I remember them well.'
    l 'Back then, substances gaining mass during burning made no sense under phlogiston theory.'
    l thinking'I suspected it had something to do with air, but hardly anyone knew what air was even made of.'
    l "I wonder, do you know, [name], what air is made of?"
    menu:  
        l "What is air made of?"
        "Is it a single element?":
            y "Is air a single element?"
            l thinking "Hmm, many people thought that, but no."
            l "Air is actually made of multiple components."
        "Is it a mixture of gases?":
            y "Is air a mixture of gases?"
            hide lavoisier
            show lavoisier happy at lcharacter
            l happy "Yes! Air is actually a mixture of gases, primarily nitrogen and oxygen."
    hide lavoisier
    show lavoisier neutral at lcharacter
    l 'Then, in August of 1774, the American alchemist Joseph Priestley met with me.'
    l 'He described an experiment where he heated mercury calx and produced what he called "dephlogistonated air."'
    l shocked '—an air that allowed candles to burn longer because it was supposedly free of phlogiston.'

    l neutral 'When I repeated his experiment, I realized this "pure air" was not magical at all.'
    l 'It was simply a component of regular air that supported combustion and respiration.'
    l 'I named it the now-famous *oxygene.*'
    if start == "Normal":
        l 'But how did I figure this out?'
        l 'Let us go back in time and see how I did. '
        jump lab_time
    else:
        l "I set up an experiment to test the phlogiston theory using a furnace, a tube with mercury, a jar with a candle, and a pan with mercury."
        l "I figured that if phlogiston theory was correct, the burnt candle would weigh less than the original candle due to the loss of phlogiston."
        l "But when I weighed the burnt candle, it actually weighed more!"
        l "I figured out that the phologiston theory was wrong because mass is gained during combustion from a component of air."

        jump lavoisier_back_to_lab
    

label lab_time:
    $ started = 0
    scene chem room at bg_zoom
    if furnace_on + tube_on + bowl_on + candlejar_on + started== 0:
        scene black
        centered ' Laboratory \n August 1774(The Past)'
        scene chem room at bg_zoom
        show lavoisier happy at lcharacter with moveinright

        n 'In the past...'
        l 'It is time to begin.'
        l 'I will use the furnace, a tube with mercury, a jar with a candle, and a pan with mercury.'
        l 'Everything must be prepared carefully. {nw}'
        show screen workstation
        hide lavoisier with moveoutright
        $started = 1
        n'Click on each item to set them up for the experiment.'
    elif furnace_on + tube_on + bowl_on + candlejar_on == 4:
        jump experiment_start
    else:
        n'Click on each item to set them up for the experiment. Hint: look for the items with a hover effect.'
        pause
label furnace:
    menu:
        'Turn on?':
            $ furnace_on = 1
            n'The furnace is on.'
            jump lab_time
        'Turn off?':
            $ furnace_on = 0
            l'Huh, why did I do that, I need that on.'
    jump lab_time
label tube:
    menu:
        'Fill?':
            $ tube_on = 1
            n'The tube is filled.'
            
            jump lab_time
        'Unfill?':
            $ tube_on = 0
            l'Huh, why did I do that, I need that to be filled.'
    jump lab_time
label bowl:
    menu:
        'Fill?':
            $ bowl_on = 1
            n'The bowl is filled.'

            jump lab_time
        'Unfill?':
            $ bowl_on = 0
            l'Huh, why did I do that, I need that to be filled.'
    
    jump lab_time
label candlejar:
    menu:
        'Light the candle?':
            $ candlejar_on = 1
            n'The candle is on.'
            jump lab_time
        'Extinguish the candle?':
            $ candlejar_on = 0
            l'Huh, why did I do that, I need that to be burning.'
    jump lab_time
label table:
    menu:
        'Turn the table on?':
            l'Um...'
            l'I dont think that did anything.'
            jump lab_time
        'Turn the table off?':
            l'Still...'
            l'What does that accomplish?'
            jump lab_time
label experiment_start:
    scene black
    scene chem room at bg_zoom
    hide screen workstation
    show lavoisier neutral at lcharacter
    l'So, now everything is on.'
    l'First let me weigh the tube, and...'
    l'Okay, it has been measured.'
    l'Now, let us start the experiment!'
    hide lavoisier 
    n'A couple hours later...'
    show lavoisier happy at lcharacter
    l'Finally, its finished!'
    l'Lets weigh this again, and...'
    l'Oh...'
    hide lavoisier
    show lavoisier shocked at lcharacter
    l'The burnt one weighs more?'
    stop music fadeout 3.0
    play music 'hammer.mp3' loop
    l'This can NOT be right!'
    l'This destroys everything I learned about phlogiston!'
    jump questioning_phlogiston
label questioning_phlogiston:
    hide lavoisier
    show lavoisier thinking at thinking_char
    menu:
        l'The phlogiston theory means what?'
        'Mass must be gained during combustion.':
            hide lavoisier
            show lavoisier sad at lcharacter
            l'Mass must be gained during combustion.'
            l'That can NOT be correct.'
            jump questioning_phlogiston
        'Mass is lost during combustion.':
            hide lavoisier
            show lavoisier shocked at lcharacter
            l'Mass is lost during combustion.'
            l'The released matter is phlogiston.'
            jump questioning_phlogiston2
        'Mass changes unpredictably during combustion.':
            hide lavoisier
            show thinking at thinking_char
            l'Mass changes unpredictably during combustion.'
            l'No, that cant be right.\n That isnt scientific, and what the theory states.'
            jump questioning_phlogiston
label questioning_phlogiston2:
    hide lavoisier
    show lavoisier thinking at thinking_char
    menu:
        l'But, this experiment shows that...'
        'Mass is gained during combustion.':
            hide lavoisier
            show lavoisier happy at lcharacter
            l'Mass is gained during combustion.'
            l'YES! Thats what my measurements show, plus they disprove the phlogiston theory!'
            jump questioning_phlogiston3
        'Mass is lost during combustion.':
            hide lavoisier
            show lavoisier shocked at lcharacter
            l'Mass is lost during combustion.'
            l'No, that cant be right. That contradicts my findings.'
            jump questioning_phlogiston2
        'Mass remains constant during combustion.':
            hide lavoisier
            show lavoisier thinking at thinking_char    
            l'Mass remains constant during combustion.'
            l'No, that cant be right.\n My measurements show otherwise.'
            jump questioning_phlogiston2
label questioning_phlogiston3:
    hide lavoisier
    show lavoisier thinking at thinking_char
    menu:
        l'So, phlogiston theory is wrong because...'
        'Combustion involves gaining mass from something.':
            l'Combustion involves gaining mass from something.'
            l'YES! That explains everything!'
            jump questioning_phlogiston4
        'Combustion involves losing mass to something.':
            l'Combustion involves losing mass to air.'
            l'No, that contradicts my findings.'
            jump questioning_phlogiston3
        'Combustion does not involve mass change.':
            l'Combustion does not involve mass change.'
            l'No, that cant be right.\n My measurements show otherwise.'
            jump questioning_phlogiston3
label questioning_phlogiston4:
    hide lavoisier
    show lavoisier happy at lcharacter
    l'Combustion involves gaining mass from something.'
    l'I need to figure out what that something is!'
    l'What could that something be?'
    menu:
        l'It was a airtight sealed tube with mercury, so it must be a gas.'
        'A component of air.':
            l'A component of air.'
            l'Yes! Air must have something that combines during combustion!'
            jump lavoisier_back_to_lab
        'Water vapor':
            l'Water vapor.'
            l'No, that can not be right.\n Water vapor is a product of combustion, not a reactant.'
            jump questioning_phlogiston4
        'Phlogiston after all.':
            l'Phlogiston after all.'
            l'No, my experiment disproves that theory.'
            jump questioning_phlogiston4

label lavoisier_back_to_lab:
    scene black
    stop music fadeout 3.0
    play music 'backgroundmusic.mp3' loop
    $ renpy.music.set_volume(0.3)
    scene chem room at bg_zoom
    with fade
    show lavoisier happy at lcharacter

    l 'Even though I neutralized the idea of phlogiston—get it?—'
    l 'There were still people who didn’t believe chemistry was legit.'

    show thinking at lcharacter
    l 'Henry Cavendish, for example, discovered a substance that burned easily.'
    l 'He called it "inflammable air."'

    hide thinking
    show lavoisier thinking at thinking_char

    l 'But with observations from Joseph Priestley, I concluded this "inflammable air" was actually the element hydrogen.'
    l 'Because when reacted,  it created a dew-like substance that was actually pure water. '

    # Continue into your hydrogen–oxygen/water explanation or next scene.
    jump lavoisier_books

label lavoisier_books:
    scene home at bg_home
    with fade
    show lavoisier happy at lcharacter

    l 'Eventually, I, along with other chemists, started completely recategorizing and redefining the world of chemistry.'
    l 'With these discoveries, I was able to publish my findings in my book "Elements of Chemistry" in 1789.'
    l '{i}Its a great read - You should buy one.{/i}'
    l 'This book is considered the first modern chemical textbook.'
    l 'It outlined important information on chemical reactions, combustions, heat, etc., but the most important one was Lavoisier’s Law, known today as the Law of Conservation of Mass. '
    l 'It states that matter is neither created nor destroyed in a chemical reaction.'
    l 'However, these conclusions couldn’t have come from nowhere! I needed help from someone to help further my scientific research.'
    l 'Would you like to know who?'
    menu:
        l 'Would you like to know who?'
            
        'Yes, tell me!':
            $ love += 1
            show lavoisier happy at lcharacter
            l 'Your mind is like groups 1 and 17 – so eager to bond with knowledge!'
            jump lavoisier_marie
        'No thanks.':
            $ love -= 1
            show lavoisier sad at lcharacter
            l 'I think I might have to rethink my hiring choices…'
            jump lavoisier_marie
label lavoisier_marie:
    hide lavoisier
    show marie happy at lcharleft_flip onlayer master
    show lavoisier happy at lcharacter onlayer master
    with moveinleft
    huh "Hey Antoine!"
    l "Oh, hello!"
    y "{i}They don’t talk like boss and assistant… more like a couple.{/i}"
    l "Here she is! My beautiful wife!"
    huh 'Thank you honey.'
    y "{i}Well, that explains it.{/i}"
    m 'My name is Marie-Anne Paulze Lavoisier.'
    m 'I am married to Lavoisier, the genius chemist.'
    l 'I was around 30 and she was 14 when we married!'
    l 'Age really is just a number!'
    m 'I helped a lot with his work, translating them into English.'
    l 'There is a reason she is known as {i}The Mother of Chemistry{/i}!' 
    m 'I even drew sketches of experiments and wrote many of his lab entries as well.'
    l 'Thank you! Is there anything you need, dear?'
    m 'Oh, actually yes. I need some help translating some text!'
    m 'Would you like to help?'
    menu:
        'Yes, gladly!':
            $ love += 1
            m 'Oh honey, you hired such a great assistant!'
            l 'I know, he has been really helpful.'
            
        'No':
            $ love -= 1
            l 'You will NOT talk to my wife like that when you are my assistant!'
            m '{i}How dissapointing.{/i}'
    m 'Here it is. Can you unscramble it?'
    jump lavoisier_input
label lavoisier_input:
    $ message = False
    while not message:
        $ translate = renpy.input('1794 loves May beheaded he On front 8 Lavoisier the be will country of in')
        $ translate = translate.strip()   # remove extra spaces

        if translate in valid_phrases:
            $ message = True
            m 'Yes, that makes sense!'
        else:
            m 'I dont think that is right...'

 

    m 'Good job, but should we tell Lavoisier? It would be heartless!'
    menu:
        'Tell Lavoisier?':
            $love -= 1
            m 'Oh, how cruel!'
            n '*Shows Lavoisier*'
            l 'Huh...'
            l 'HAHAHAHA'
            menu:
                'What?':
                    y 'Why are you laughing?'
                'Also Laugh':
                    y 'Ha Ha Ha...'
                    m 'Why are you both laughing?!'
            l 'You really think I believe this tomfoolery?! No, I dont.'
            l 'Thank you for that, but I dont think so.'
        'Keep it a secret?:':
            $ love += 1
            m 'What a kind soul.'
    l 'That was good fun, watching you help my wife.'
    m 'Yes, but I have to go now. Bye!'
    hide marie happy with moveoutleft
    hide lavoisier
    show lavoisier thinking at thinking_char
    l 'Ah, now where was I…'
    hide lavoisier
    show lavoisier shocked at lcharacter
    l 'Yes, my later years, they are a bit “fuzzy” as you Americans say.'
    hide lavoisier
    show lavoisier neutral at lcharacter
    l 'Later, after publishing my book and presenting my famous theories to the world, I joined a private tax-collecting group called the Ferme Générale.'
    l ' I also became a member of the Gunpowder Commission to regulate the production of Gunpowder in France.'
    l 'I also moved my laboratory closer to my place of work and hosted young aspiring chemists to have intellectual conversations and conduct experiments with me.'
    l 'Like you!'
    l 'Speaking about you, time to work!'
    jump lavoisier_death
label lavoisier_death:
    stop music
    scene black
    centered 'Early May, 1794'
    scene black
    scene animated_bookshelf at bgzoom
    show lavoisier happy at lcharacter
    l 'This tea is excellent! You did well to prepare it.'
    y "{i}For someone who changed the world, he looks oddly human right now.{/i}"
    y "Thank you, Master Lavoisier."
    n 'A man knocks at the door, handing a newspaper to you.'
    stop music
    play music pursuit loop
    n 'The newspaper reads {i}Jean Paul Marat denounces Lavoisier! Ferme Générale is getting arrested!{/i}'
    y 'SIR! Look what this says!'
    hide lavoisier
    show lavoisier shocked at lcharacter
    l 'WHAT! We can NOT be getting arrested!'
    scene black
    centered 'BAM! The door falls to the ground, revealing multiple members of the police.'
    centered '{i}LAVOISIER, GET ON THE GROUND!{/i}'
    scene animated_bookshelf at bgzoom
    show lavoisier shocked at lcharacter
    
    l 'Yes sir.'
    n 'Lavoisier drops to the ground.'
    scene black
    centered '{i}Now, who is this?{/i}'
    scene animated_bookshelf at bgzoom
    show lavoisier sad at lcharacter
    n 'The police points at you.'
    if love < 0:
        l '[gender] is my apprentice, and a part of the Ferme Générale.'
        n '{i}Really? GET ON THE GROUND!{/i}'
        jump bad_ending
    elif love >= 1:
        l '[gender] is my apprentice.'
        n 'GET ON THE GROUND!'
        l 'NO, DO NOT TAKE THEM!'
        l 'There is no reason to take them.'
        jump good_ending
    elif love == 0:
        l '[gender] is my apprentice.'
        n 'GET ON THE GROUND!'
        n "{i}As this happened, you realized something...{/i}"
        y "{i} He said nothing... \n I wonder what would have happened if I were kinder...{/i}"
        jump bad_ending

label bad_ending:
    hide lavoisier
    scene black
    stop music
    play music sad loop
    

    centered 'On May 8th, 1794, Lavoisier was beheaded.'
    if love == 0:
        centered 'Along with him, you were also killed, being nothing special for him to protect you.'
    elif love < 0:
        centered 'Along with him, you were also killed, being mean to him [love] times.'
    
    
    l "My companion, Joseph-Louis Lagrange, a brilliant mathematician, mourned my execution. He said, “It took them only an instant to cut off that head, and a hundred years may not produce another like it.”"

    centered "His words echoed across Paris — a reminder that the Revolution had not just taken a life, but silenced one of science’s greatest minds."

    l "The day of my death became a mark of tragedy in the history of France, and in the history of chemistry itself."
    centered "As the blade fell, your thoughts rang out..."
    y "{i}This can’t be happening… someone stop this!{/i}"
    y "{i}I don’t want to die here. Stay calm. Stay calm…{/i}"
    y "{i}I wonder what would have happened if I were kinder?{/i}"
    centered "And you, laying down next to him... joined him in death."

    centered "The End."
    return
label good_ending:
            
    hide lavoisier
    scene black

    
    
    centered 'On May 8th, 1794, Lavoisier was beheaded.'
    centered "Because you treated him kindly [love] times, you were spared."

    l "My companion, Joseph-Louis Lagrange, a brilliant mathematician, mourned my execution. He said, “It took them only an instant to cut off that head, and a hundred years may not produce another like it.”"
    centered "His words echoed across Paris — a reminder that the Revolution had not just taken a life, but silenced one of science’s greatest minds."

    l "The day of my death became a mark of tragedy in the history of France, and in the history of chemistry itself."
    centered "As the blade fell, your thoughts rang out..."
    y "{i}This can’t be happening… someone stop this!{/i}"
    y "{i}He can't die! He did too much to die like this! {/i}"
    centered "And you, standing there as the blade fell… lived on to remember it."

    centered "The End."
    return
            


